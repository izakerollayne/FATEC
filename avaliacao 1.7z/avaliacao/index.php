<?php
 
?>
 
<!DOCTYPE html>
<html lang="pt_BR">
<head>
    <meta charset="UTF-8">
    <title>Acessar</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Solicitações laboratóriais</h2>
        <p>Favor inserir login e senha para realizar solicitações:</p>
     
        <a href="login.php"><button type="button" class="btn btn-primary btn-sm">login</button></a>
        <a href="solicitacoes.php"><button type="button" class="btn btn-secondary btn-sm">Visualizar solicitações</button></a>

    </div>    
</body>
</html>